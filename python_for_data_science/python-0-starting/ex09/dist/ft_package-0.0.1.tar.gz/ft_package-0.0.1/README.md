# ft_package

This is a sample Python package for educational purposes.

## Installation

Install the package using pip:

```bash
pip install ./dist/ft_package-0.0.1.tar.gz
pip install ./dist/ft_package-0.0.1-py3-none-any.whl
```
